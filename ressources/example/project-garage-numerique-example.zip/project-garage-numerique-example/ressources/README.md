Folder containing ressources pre-code
